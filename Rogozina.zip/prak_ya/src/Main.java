import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Admin admin = new Admin(1);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Добро пожаловать в клиентскую базу 'Бебровы горы'!");
            System.out.println("Выберите из всплывающего списка:");
            System.out.println("1. Добавить нового пользователя");
            System.out.println("2. Удалить пользователя");
            System.out.println("3. Создать запись в отеле");
            System.out.println("4. Удалить запись в отеле");
            System.out.println("5. Выйти из клиентской базы");

            int choice = scanner.nextInt();
            scanner.nextLine(); // очистка буфера

            switch (choice) {
                case 1:
                    admin.addUser(scanner);
                    admin.displayUsers();
                    break;
                case 2:
                    admin.deleteUser(scanner);
                    admin.displayUsers();
                    break;
                case 3:
                    admin.addHotelRecord(scanner);
                    admin.displayHotelRecords();
                    break;
                case 4:
                    admin.deleteHotelRecords(scanner);
                    admin.displayHotelRecords();
                    break;
                case 5:
                    System.out.println("Вы покинули клиентскую базу 'Бебровы горы'!");
                    return;
                default:
                    System.out.println("Некорректный ввод. Пожалуйста, выберите действие из списка.");
                    break;
            }
        }
    }
}