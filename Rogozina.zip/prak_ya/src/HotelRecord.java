public class HotelRecord {
    private int ID_user;
    private int roomNumber;
    private String checkInDate;
    private String checkOutDate;


    public HotelRecord(int roomNumber, String checkInDate, String checkOutDate, int ID_user) {
        this.ID_user = ID_user;
        this.roomNumber = roomNumber;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;

    }
    public int getID_user() {
        return ID_user;
    }
    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(String checkInDate) {
        this.checkInDate = checkInDate;
    }

    public String getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }


}
