import java.util.ArrayList;
import java.util.Scanner;

public class Admin {
    private int id;
    private ArrayList<User> users = new ArrayList<>();
    private ArrayList<HotelRecord> hotelRecords = new ArrayList<>();

    public Admin(int id) {
        this.id = id;
    }

    public void addUser(Scanner scanner) {
        System.out.print("Введите ID нового пользователя: ");
        int newUserId = scanner.nextInt();
        scanner.nextLine(); // очистка буфера
        System.out.print("Введите имя нового пользователя: ");
        String newName = scanner.nextLine();
        System.out.print("Введите телефон нового пользователя: ");
        String newPhone = scanner.nextLine();

        User newUser = new User(newUserId, newName, newPhone);
        users.add(newUser);
    }

    public void deleteUser(Scanner scanner) {
        System.out.print("Введите ID пользователя для удаления: ");
        int userId = scanner.nextInt();

        users.removeIf(user -> user.getId() == userId);
    }

    public void addHotelRecord(Scanner scanner) {
        System.out.println("Введите ID клиента");
        int Id_user = scanner.nextInt();
        System.out.print("Введите номер комнаты: ");
        int roomNumber = scanner.nextInt();
        scanner.nextLine(); // очистка буфера
        System.out.print("Дата заселения: ");
        String checkInDate = scanner.nextLine();
        System.out.print("Дата выселения: ");
        String checkOutDate = scanner.nextLine();

        HotelRecord newRecord = new HotelRecord(roomNumber, checkInDate, checkOutDate,Id_user);
        hotelRecords.add(newRecord);
    }

    public void deleteHotelRecords(Scanner scanner) {
        System.out.print("Введите номер комнаты: ");
        int roomNumber = scanner.nextInt();

        hotelRecords.removeIf(hotelRecord -> hotelRecord.getRoomNumber() == roomNumber);
    }

        public void displayUsers () {
            System.out.println("Список пользователей:");
            for (User user : users) {
                System.out.println(user.getId() + " - " + user.getName() + " - " + user.getPhone());
            }
        }

        public void displayHotelRecords () {
            System.out.println("Записи в отеле:");
            for (HotelRecord record : hotelRecords) {
                System.out.println("ID пользователя: " + record.getID_user() + ", Номер комнаты: "
                        + record.getRoomNumber() + ", Дата заселения: " + record.getCheckInDate() +
                        ", Дата выселения: " + record.getCheckOutDate());
            }
        }
    }
